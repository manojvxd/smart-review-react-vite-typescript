import React from 'react';
import './Breadcrumb.css';

const Breadcrumb: React.FC = () => {
  return (
    <nav className="breadcrumb">
      <div className="breadcrumb-item">
        <span>Home</span>
      </div>
      <div className="breadcrumb-separator"> </div>
      <div className="breadcrumb-item">
        <span>Sessions</span>
      </div>
      <div className="breadcrumb-separator"> </div>
      <div className="breadcrumb-item">
        <span>IRD_Doc_0001</span>
      </div>
      <div className="breadcrumb-separator"> </div>
      <div className="breadcrumb-item current">
        <span>IRD_Doc_0001.pdf</span>
      </div>
    </nav>
  );
};

export default Breadcrumb; 