import React, { useState } from 'react';
import { ChevronUp, ChevronDown, FileText, Calendar, MoreVertical, Plus, Filter } from 'lucide-react';
import './LeftPanel.css';

interface Document {
  id: string;
  name: string;
  info: string;
  docNumber: string;
  sheetNumber: string;
  status: 'active' | 'inactive';
  type: 'pdf' | 'doc' | 'xls';
}

interface Session {
  id: string;
  name: string;
  status: 'in-progress' | 'completed' | 'pending';
  startDate: string;
  endDate: string;
  creator: string;
  createdDate: string;
}

interface LeftPanelProps {
  documents: Document[];
  session: Session;
  selectedDocument: string;
  onDocumentSelect: (documentId: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const LeftPanel: React.FC<LeftPanelProps> = ({
  documents,
  session,
  selectedDocument,
  onDocumentSelect,
  isCollapsed,
  onToggleCollapse
}) => {
  const [isDocumentsExpanded, setIsDocumentsExpanded] = useState(true);
  const [isSessionExpanded, setIsSessionExpanded] = useState(true);
  const [showDocumentMenu, setShowDocumentMenu] = useState<string | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in-progress':
        return '#FFFABE';
      case 'completed':
        return '#42D98B';
      case 'pending':
        return '#FFC852';
      default:
        return '#FFFABE';
    }
  };

  const getStatusTextColor = (status: string) => {
    switch (status) {
      case 'in-progress':
        return '#A69931';
      case 'completed':
        return '#1F7A3A';
      case 'pending':
        return '#B45309';
      default:
        return '#A69931';
    }
  };

  const getDocumentIcon = (type: string) => {
    switch (type) {
      case 'pdf':
        return '📄';
      case 'doc':
        return '📝';
      case 'xls':
        return '📊';
      default:
        return '📄';
    }
  };

  return (
    <div className={`left-panel ${isCollapsed ? 'collapsed' : ''}`}>
      {/* Collapse Toggle Button */}
      <button 
        className="panel-toggle-btn"
        onClick={onToggleCollapse}
        title={isCollapsed ? 'Expand Panel' : 'Collapse Panel'}
      >
        <ChevronDown className={isCollapsed ? 'rotate' : ''} size={16} />
      </button>

      {/* Documents Section */}
      <div className="panel-section documents-section">
        <div 
          className="section-header"
          onClick={() => setIsDocumentsExpanded(!isDocumentsExpanded)}
        >
          <FileText size={16} />
          <span>Documents ({documents.length})</span>
          <div className="header-actions">
            <button className="action-btn" title="Add Document">
              <Plus size={14} />
            </button>
            <button className="action-btn" title="Filter Documents">
              <Filter size={14} />
            </button>
            {isDocumentsExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </div>
        </div>
        
        {isDocumentsExpanded && (
          <div className="documents-list">
            {documents.map((document) => (
              <div 
                key={document.id}
                className={`document-card ${selectedDocument === document.id ? 'selected' : ''} ${document.status === 'inactive' ? 'inactive' : ''}`}
                onClick={() => onDocumentSelect(document.id)}
              >
                <div className={`document-indicator ${document.status === 'active' ? 'bg-blue' : 'bg-light-blue'}`}></div>
                <div className="document-content">
                  <div className="document-info">
                    <div className="document-name">
                      <span className="label">Document Name:</span>
                      <div className="file-info">
                        <span className="file-icon">{getDocumentIcon(document.type)}</span>
                        <span className="file-name">{document.name}</span>
                      </div>
                    </div>
                    <div className="document-details">
                      <span className="label">Document Info:</span>
                      <span>{document.info}</span>
                    </div>
                  </div>
                  <div className="document-meta">
                    <div className="doc-number">Doc: #{document.docNumber}</div>
                    <div className="sheet-number">Sheet No: {document.sheetNumber}</div>
                    <div className="document-actions">
                      <button 
                        className="more-options"
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowDocumentMenu(showDocumentMenu === document.id ? null : document.id);
                        }}
                      >
                        <MoreVertical size={14} />
                      </button>
                      {showDocumentMenu === document.id && (
                        <div className="document-menu">
                          <div className="menu-item">View Details</div>
                          <div className="menu-item">Download</div>
                          <div className="menu-item">Share</div>
                          <div className="menu-divider"></div>
                          <div className="menu-item danger">Delete</div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Session Info Section */}
      <div className="panel-section session-section">
        <div 
          className="section-header"
          onClick={() => setIsSessionExpanded(!isSessionExpanded)}
        >
          <Calendar size={16} />
          <span>Session Details</span>
          {isSessionExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </div>
        
        {isSessionExpanded && (
          <div className="session-content">
            <div className="session-header">
              <div className="session-name">
                <span className="label">Session Name:</span>
                <span className="value">{session.name}</span>
              </div>
              <div className="session-status">
                <span 
                  className="status-badge"
                  style={{
                    backgroundColor: getStatusColor(session.status),
                    color: getStatusTextColor(session.status)
                  }}
                >
                  {session.status.replace('-', ' ')}
                </span>
              </div>
            </div>
            
            <div className="session-dates">
              <div className="date-group">
                <span className="label">Start Date</span>
                <div className="date-input">
                  <Calendar size={16} />
                  <span>{session.startDate}</span>
                </div>
              </div>
              <div className="date-group">
                <span className="label">End Date</span>
                <div className="date-input">
                  <Calendar size={16} />
                  <span>{session.endDate}</span>
                </div>
              </div>
            </div>
            
            <div className="session-meta">
              <div className="session-number">Session: #{session.id.split('-')[1]}</div>
              <div className="session-creator">
                <span>Created by: {session.creator}</span>
                <span>Date: {session.createdDate}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LeftPanel; 
