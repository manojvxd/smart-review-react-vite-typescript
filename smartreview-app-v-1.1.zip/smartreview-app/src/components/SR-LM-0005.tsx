import React, { useState, useEffect } from 'react';
import { User, MessageSquare, FileText, ChevronDown, Search, Filter, MoreVertical, Download, Share2, Eye, Settings, Bell, Calendar, Clock, CheckCircle, AlertCircle, XCircle, Plus, Star, Folder, Image, Video, Music, Archive, Trash2, Edit3, Copy, ExternalLink, Grid3X3, List, Filter as FilterIcon, SortAsc, SortDesc } from 'lucide-react';
import './SR-LM-0005.css';

interface Document {
  id: string;
  name: string;
  type: string;
  size: string;
  lastModified: string;
  status: 'active' | 'inactive' | 'pending' | 'completed' | 'overdue' | 'archived';
  priority: 'high' | 'medium' | 'low';
  assignee: string;
  dueDate: string;
  category: 'documents' | 'images' | 'videos' | 'audio' | 'archives';
  isStarred: boolean;
  isSelected: boolean;
  thumbnail?: string;
}

interface Comment {
  id: string;
  author: string;
  content: string;
  timestamp: string;
  avatar: string;
  replies?: Comment[];
}

interface Participant {
  id: string;
  name: string;
  role: string;
  avatar: string;
  isActive: boolean;
  status: 'online' | 'offline' | 'away';
}

interface Task {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed';
  priority: 'high' | 'medium' | 'low';
  assignee: string;
  dueDate: string;
  progress: number;
}

interface Category {
  id: string;
  name: string;
  icon: React.ReactNode;
  count: number;
  color: string;
}

interface FilterOption {
  id: string;
  name: string;
  icon: React.ReactNode;
}

const SR_LM_0005: React.FC = () => {
  const [documents, setDocuments] = useState<Document[]>([
    {
      id: '1',
      name: 'SR-LM-0005.pdf',
      type: 'PDF',
      size: '5.8 MB',
      lastModified: '15 minutes ago',
      status: 'active',
      priority: 'high',
      assignee: 'Alex Johnson',
      dueDate: '2024-01-25',
      category: 'documents',
      isStarred: true,
      isSelected: false
    },
    {
      id: '2',
      name: 'Design_Mockups.fig',
      type: 'FIG',
      size: '12.3 MB',
      lastModified: '1 hour ago',
      status: 'pending',
      priority: 'medium',
      assignee: 'Sarah Chen',
      dueDate: '2024-01-28',
      category: 'images',
      isStarred: false,
      isSelected: false
    },
    {
      id: '3',
      name: 'Product_Demo.mp4',
      type: 'MP4',
      size: '67.5 MB',
      lastModified: '2 hours ago',
      status: 'completed',
      priority: 'low',
      assignee: 'Mike Rodriguez',
      dueDate: '2024-01-22',
      category: 'videos',
      isStarred: true,
      isSelected: false
    },
    {
      id: '4',
      name: 'Background_Music.mp3',
      type: 'MP3',
      size: '18.9 MB',
      lastModified: '1 day ago',
      status: 'archived',
      priority: 'low',
      assignee: 'Emily Davis',
      dueDate: '2024-01-20',
      category: 'audio',
      isStarred: false,
      isSelected: false
    },
    {
      id: '5',
      name: 'Project_Backup.zip',
      type: 'ZIP',
      size: '234.1 MB',
      lastModified: '3 days ago',
      status: 'archived',
      priority: 'medium',
      assignee: 'Alex Johnson',
      dueDate: '2024-01-18',
      category: 'archives',
      isStarred: false,
      isSelected: false
    },
    {
      id: '6',
      name: 'Technical_Specs.docx',
      type: 'DOCX',
      size: '3.2 MB',
      lastModified: '4 hours ago',
      status: 'active',
      priority: 'high',
      assignee: 'Sarah Chen',
      dueDate: '2024-01-26',
      category: 'documents',
      isStarred: false,
      isSelected: false
    }
  ]);

  const [participants, setParticipants] = useState<Participant[]>([
    {
      id: '1',
      name: 'Alex Johnson',
      role: 'Project Lead',
      avatar: 'AJ',
      isActive: true,
      status: 'online'
    },
    {
      id: '2',
      name: 'Sarah Chen',
      role: 'UI/UX Designer',
      avatar: 'SC',
      isActive: true,
      status: 'online'
    },
    {
      id: '3',
      name: 'Mike Rodriguez',
      role: 'Frontend Developer',
      avatar: 'MR',
      isActive: true,
      status: 'away'
    },
    {
      id: '4',
      name: 'Emily Davis',
      role: 'QA Engineer',
      avatar: 'ED',
      isActive: false,
      status: 'offline'
    }
  ]);

  const [comments, setComments] = useState<Comment[]>([
    {
      id: '1',
      author: 'Alex Johnson',
      content: 'The new design layout looks excellent! The spacing and typography improvements really enhance the user experience.',
      timestamp: '1 hour ago',
      avatar: 'AJ'
    },
    {
      id: '2',
      author: 'Sarah Chen',
      content: 'I agree with Alex. The color scheme is much more cohesive now. Should we consider adding more interactive elements?',
      timestamp: '45 minutes ago',
      avatar: 'SC'
    },
    {
      id: '3',
      author: 'Mike Rodriguez',
      content: 'From a technical perspective, the implementation is solid. The component structure is clean and maintainable.',
      timestamp: '30 minutes ago',
      avatar: 'MR'
    }
  ]);

  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      title: 'Review Design Mockups',
      description: 'Review and approve the latest design mockups for the new interface',
      status: 'in-progress',
      priority: 'high',
      assignee: 'Alex Johnson',
      dueDate: '2024-01-25',
      progress: 75
    },
    {
      id: '2',
      title: 'Update Documentation',
      description: 'Update technical documentation with latest API changes',
      status: 'pending',
      priority: 'medium',
      assignee: 'Sarah Chen',
      dueDate: '2024-01-28',
      progress: 0
    },
    {
      id: '3',
      title: 'Code Review',
      description: 'Complete code review for the new authentication module',
      status: 'completed',
      priority: 'high',
      assignee: 'Mike Rodriguez',
      dueDate: '2024-01-22',
      progress: 100
    }
  ]);

  const [selectedDocument, setSelectedDocument] = useState<string>('1');
  const [selectedParticipant, setSelectedParticipant] = useState<string>('1');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [newComment, setNewComment] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'documents' | 'tasks'>('documents');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'name' | 'date' | 'size' | 'type'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [selectedDocuments, setSelectedDocuments] = useState<string[]>([]);
  const [isSelectMode, setIsSelectMode] = useState<boolean>(false);

  const categories: Category[] = [
    { id: 'all', name: 'All Files', icon: <Folder size={16} />, count: documents.length, color: '#3b82f6' },
    { id: 'documents', name: 'Documents', icon: <FileText size={16} />, count: documents.filter(d => d.category === 'documents').length, color: '#ef4444' },
    { id: 'images', name: 'Images', icon: <Image size={16} />, count: documents.filter(d => d.category === 'images').length, color: '#10b981' },
    { id: 'videos', name: 'Videos', icon: <Video size={16} />, count: documents.filter(d => d.category === 'videos').length, color: '#f59e0b' },
    { id: 'audio', name: 'Audio', icon: <Music size={16} />, count: documents.filter(d => d.category === 'audio').length, color: '#8b5cf6' },
    { id: 'archives', name: 'Archives', icon: <Archive size={16} />, count: documents.filter(d => d.category === 'archives').length, color: '#6b7280' }
  ];

  const filterOptions: FilterOption[] = [
    { id: 'starred', name: 'Starred', icon: <Star size={16} /> },
    { id: 'recent', name: 'Recent', icon: <Clock size={16} /> },
    { id: 'large', name: 'Large Files', icon: <FileText size={16} /> },
    { id: 'shared', name: 'Shared', icon: <Share2 size={16} /> }
  ];

  const handleDocumentSelect = (documentId: string) => {
    if (isSelectMode) {
      setSelectedDocuments(prev => 
        prev.includes(documentId) 
          ? prev.filter(id => id !== documentId)
          : [...prev, documentId]
      );
    } else {
      setSelectedDocument(documentId);
    }
  };

  const handleParticipantSelect = (participantId: string) => {
    setSelectedParticipant(participantId);
  };

  const handleAddComment = () => {
    if (newComment.trim()) {
      const comment: Comment = {
        id: Date.now().toString(),
        author: 'You',
        content: newComment.trim(),
        timestamp: 'Just now',
        avatar: 'YO'
      };
      setComments(prev => [comment, ...prev]);
      setNewComment('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleAddComment();
    }
  };

  const toggleStar = (documentId: string) => {
    setDocuments(prev => prev.map(doc => 
      doc.id === documentId ? { ...doc, isStarred: !doc.isStarred } : doc
    ));
  };

  const toggleSelectMode = () => {
    setIsSelectMode(!isSelectMode);
    if (isSelectMode) {
      setSelectedDocuments([]);
    }
  };

  const selectAll = () => {
    if (selectedDocuments.length === filteredDocuments.length) {
      setSelectedDocuments([]);
    } else {
      setSelectedDocuments(filteredDocuments.map(doc => doc.id));
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'documents':
        return <FileText size={20} />;
      case 'images':
        return <Image size={20} />;
      case 'videos':
        return <Video size={20} />;
      case 'audio':
        return <Music size={20} />;
      case 'archives':
        return <Archive size={20} />;
      default:
        return <FileText size={20} />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'documents':
        return '#ef4444';
      case 'images':
        return '#10b981';
      case 'videos':
        return '#f59e0b';
      case 'audio':
        return '#8b5cf6';
      case 'archives':
        return '#6b7280';
      default:
        return '#3b82f6';
    }
  };

  const sortDocuments = (docs: Document[]) => {
    return [...docs].sort((a, b) => {
      let comparison = 0;
      switch (sortBy) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'date':
          comparison = new Date(a.lastModified).getTime() - new Date(b.lastModified).getTime();
          break;
        case 'size':
          comparison = parseFloat(a.size) - parseFloat(b.size);
          break;
        case 'type':
          comparison = a.type.localeCompare(b.type);
          break;
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });
  };

  const filteredDocuments = sortDocuments(documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || doc.category === selectedCategory;
    return matchesSearch && matchesCategory;
  }));

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle size={16} className="status-icon completed" />;
      case 'overdue':
        return <XCircle size={16} className="status-icon overdue" />;
      case 'pending':
        return <Clock size={16} className="status-icon pending" />;
      case 'archived':
        return <Archive size={16} className="status-icon archived" />;
      default:
        return <AlertCircle size={16} className="status-icon active" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return '#ef4444';
      case 'medium':
        return '#f59e0b';
      case 'low':
        return '#10b981';
      default:
        return '#6b7280';
    }
  };

  return (
    <div className="app-container">
      {/* Header */}
      <header className="header">
        <div className="header-left">
          <a href="#" className="logo">SmartReview</a>
          <div className="breadcrumb">
            <span>Projects</span>
            <span className="breadcrumb-separator">/</span>
            <span>Document Review</span>
            <span className="breadcrumb-separator">/</span>
            <span>SR-LM-0005</span>
          </div>
        </div>
        <div className="header-right">
          <div className="header-actions">
            <button className="action-button">
              <Search size={16} />
            </button>
            <button className="action-button">
              <Filter size={16} />
            </button>
            <button className="action-button">
              <Bell size={16} />
            </button>
            <button className="action-button">
              <Settings size={16} />
            </button>
            <button className="action-button">
              <Download size={16} />
            </button>
            <button className="action-button">
              <Share2 size={16} />
            </button>
          </div>
          <div className="user-menu">
            <div className="user-avatar">AJ</div>
            <span>Alex Johnson</span>
            <ChevronDown size={12} className="chevron-icon" />
          </div>
        </div>
      </header>

      {/* Left Panel - Categories & Documents */}
      <aside className="left-panel">
        <div className="panel-header">
          <div className="panel-tabs">
            <button 
              className={`tab-button ${activeTab === 'documents' ? 'active' : ''}`}
              onClick={() => setActiveTab('documents')}
            >
              Files
            </button>
            <button 
              className={`tab-button ${activeTab === 'tasks' ? 'active' : ''}`}
              onClick={() => setActiveTab('tasks')}
            >
              Tasks
            </button>
          </div>
          <p className="panel-subtitle">
            {activeTab === 'documents' ? `${filteredDocuments.length} files` : `${tasks.length} tasks`}
          </p>
        </div>
        
        <div className="search-container">
          <div className="search-input-wrapper">
            <Search size={16} className="search-icon" />
            <input
              type="text"
              placeholder={`Search ${activeTab}...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
            />
          </div>
        </div>

        {activeTab === 'documents' && (
          <div className="categories-section">
            <div className="categories-header">
              <h3>Categories</h3>
              <button className="view-toggle">
                {viewMode === 'grid' ? <List size={16} /> : <Grid3X3 size={16} />}
              </button>
            </div>
            <div className="categories-list">
              {categories.map((category) => (
                <div
                  key={category.id}
                  className={`category-item ${selectedCategory === category.id ? 'active' : ''}`}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <div className="category-icon" style={{ color: category.color }}>
                    {category.icon}
                  </div>
                  <div className="category-info">
                    <span className="category-name">{category.name}</span>
                    <span className="category-count">{category.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'documents' ? (
          <div className={`documents-container ${viewMode}`}>
            <div className="documents-toolbar">
              <div className="toolbar-left">
                <button 
                  className={`select-mode-button ${isSelectMode ? 'active' : ''}`}
                  onClick={toggleSelectMode}
                >
                  <CheckCircle size={16} />
                  Select
                </button>
                {isSelectMode && (
                  <button className="select-all-button" onClick={selectAll}>
                    {selectedDocuments.length === filteredDocuments.length ? 'Deselect All' : 'Select All'}
                  </button>
                )}
                {selectedDocuments.length > 0 && (
                  <span className="selected-count">{selectedDocuments.length} selected</span>
                )}
              </div>
              <div className="toolbar-right">
                <div className="sort-controls">
                  <select 
                    className="sort-select"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                  >
                    <option value="name">Name</option>
                    <option value="date">Date</option>
                    <option value="size">Size</option>
                    <option value="type">Type</option>
                  </select>
                  <button 
                    className="sort-order-button"
                    onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                  >
                    {sortOrder === 'asc' ? <SortAsc size={16} /> : <SortDesc size={16} />}
                  </button>
                </div>
                <button 
                  className={`filter-toggle ${showFilters ? 'active' : ''}`}
                  onClick={() => setShowFilters(!showFilters)}
                >
                  <FilterIcon size={16} />
                </button>
              </div>
            </div>

            {showFilters && (
              <div className="filters-panel">
                <div className="filters-grid">
                  {filterOptions.map((filter) => (
                    <button key={filter.id} className="filter-option">
                      {filter.icon}
                      <span>{filter.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {viewMode === 'grid' ? (
              <div className="documents-grid">
                {filteredDocuments.map((document) => (
                  <div
                    key={document.id}
                    className={`document-card ${selectedDocument === document.id ? 'active' : ''} ${selectedDocuments.includes(document.id) ? 'selected' : ''}`}
                    onClick={() => handleDocumentSelect(document.id)}
                  >
                    <div className="document-card-header">
                      <div className="document-icon" style={{ color: getCategoryColor(document.category) }}>
                        {getCategoryIcon(document.category)}
                      </div>
                      <div className="document-actions">
                        <button 
                          className={`star-button ${document.isStarred ? 'starred' : ''}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleStar(document.id);
                          }}
                        >
                          <Star size={14} />
                        </button>
                        <button className="more-button">
                          <MoreVertical size={14} />
                        </button>
                      </div>
                    </div>
                    <div className="document-card-content">
                      <div className="document-name">{document.name}</div>
                      <div className="document-meta">
                        <span className="document-size">{document.size}</span>
                        <span className="document-date">{document.lastModified}</span>
                      </div>
                      <div className="document-status">
                        {getStatusIcon(document.status)}
                        <span className="status-text">{document.status}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="documents-list">
                {filteredDocuments.map((document) => (
                  <div
                    key={document.id}
                    className={`document-item ${selectedDocument === document.id ? 'active' : ''} ${selectedDocuments.includes(document.id) ? 'selected' : ''}`}
                    onClick={() => handleDocumentSelect(document.id)}
                  >
                    <div className="document-icon" style={{ color: getCategoryColor(document.category) }}>
                      {getCategoryIcon(document.category)}
                    </div>
                    <div className="document-info">
                      <div className="document-name">{document.name}</div>
                      <div className="document-meta">
                        <span className="document-type">{document.type}</span>
                        <span className="document-size">{document.size}</span>
                        <span className="document-date">{document.lastModified}</span>
                      </div>
                      <div className="document-details">
                        <span className="assignee">Assigned to {document.assignee}</span>
                        <span className="due-date">Due: {document.dueDate}</span>
                        <div 
                          className="priority-indicator" 
                          style={{ backgroundColor: getPriorityColor(document.priority) }}
                        />
                      </div>
                    </div>
                    <div className="document-actions">
                      <button 
                        className={`star-button ${document.isStarred ? 'starred' : ''}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleStar(document.id);
                        }}
                      >
                        <Star size={14} />
                      </button>
                      <button className="document-action">
                        <Eye size={14} />
                      </button>
                      <button className="document-action">
                        <MoreVertical size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="tasks-list">
            {tasks.map((task) => (
              <div key={task.id} className="task-item">
                <div className="task-header">
                  <div className="task-title">{task.title}</div>
                  <div 
                    className="priority-indicator" 
                    style={{ backgroundColor: getPriorityColor(task.priority) }}
                  />
                </div>
                <div className="task-description">{task.description}</div>
                <div className="task-meta">
                  <span className="assignee">Assigned to {task.assignee}</span>
                  <span className="due-date">Due: {task.dueDate}</span>
                </div>
                <div className="task-progress">
                  <div className="progress-bar">
                    <div 
                      className="progress-fill" 
                      style={{ width: `${task.progress}%` }}
                    />
                  </div>
                  <span className="progress-text">{task.progress}%</span>
                </div>
                <div className="task-status">
                  {getStatusIcon(task.status)}
                  <span className="status-text">{task.status}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        <div className="document-viewer">
          <div className="document-placeholder">
            <FileText size={64} className="document-icon-large" />
            <h3>SR-LM-0005.pdf</h3>
            <p>Document viewer will be displayed here</p>
            <div className="document-stats">
              <div className="stat">
                <span className="stat-label">Pages</span>
                <span className="stat-value">58</span>
              </div>
              <div className="stat">
                <span className="stat-label">Size</span>
                <span className="stat-value">5.8 MB</span>
              </div>
              <div className="stat">
                <span className="stat-label">Last Modified</span>
                <span className="stat-value">15 minutes ago</span>
              </div>
              <div className="stat">
                <span className="stat-label">Due Date</span>
                <span className="stat-value">Jan 25, 2024</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Right Panel - Comments & Participants */}
      <aside className="right-panel">
        <div className="panel-tabs">
          <button className="tab-button active">Comments</button>
          <button className="tab-button">Participants</button>
        </div>
        
        <div className="comments-section">
          <div className="comments-header">
            <h2 className="comments-title">Comments</h2>
            <p className="comments-count">{comments.length} comments</p>
          </div>
          <div className="comments-list">
            {comments.map((comment) => (
              <div key={comment.id} className="comment-item fade-in">
                <div className="comment-avatar">{comment.avatar}</div>
                <div className="comment-content-wrapper">
                  <div className="comment-header">
                    <span className="comment-author">{comment.author}</span>
                    <span className="comment-time">{comment.timestamp}</span>
                  </div>
                  <div className="comment-content">{comment.content}</div>
                  <div className="comment-actions">
                    <span className="comment-action">Reply</span>
                    <span className="comment-action">Resolve</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="add-comment">
          <textarea
            className="comment-input"
            placeholder="Add a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            onKeyDown={handleKeyPress}
          />
          <button className="comment-submit" onClick={handleAddComment}>
            Post Comment
          </button>
        </div>
      </aside>
    </div>
  );
};

export default SR_LM_0005; 