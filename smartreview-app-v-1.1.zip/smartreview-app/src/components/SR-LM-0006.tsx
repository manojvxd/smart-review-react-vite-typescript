import React, { useState } from 'react';
import { User, MessageSquare, FileText, ChevronDown, Search, Filter, MoreVertical, Download, Share2, Eye, Settings, Bell, Calendar, Clock, CheckCircle, AlertCircle, XCircle, Plus, Star, Folder, Image, Video, Music, Archive, Trash2, Edit3, Copy, ExternalLink, Grid3X3, List, Filter as FilterIcon, SortAsc, SortDesc, Users, Mail, Phone, MapPin, Globe, Linkedin, Twitter, Github, Zap, Target, TrendingUp, BarChart3, PieChart, Activity, Shield, Lock, Unlock, Key, Database, Server, Cloud, Wifi, Signal, Battery, Volume2, VolumeX, Mic, MicOff, Camera, Video as VideoIcon, Headphones, Monitor, Smartphone, Tablet, Watch, Printer, Scanner, HardDrive, MemoryStick, Router, Modem, Satellite, Antenna } from 'lucide-react';
import './SR-LM-0006.css';

const SR_LM_0006: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'documents' | 'tasks' | 'system'>('documents');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showSystemPanel, setShowSystemPanel] = useState(false);

  return (
    <div className="app-container">
      {/* Header */}
      <header className="header">
        <div className="header-left">
          <a href="#" className="logo">SmartReview</a>
          <div className="breadcrumb">
            <span>Projects</span>
            <span className="breadcrumb-separator">/</span>
            <span>Document Review</span>
            <span className="breadcrumb-separator">/</span>
            <span>SR-LM-0006</span>
          </div>
        </div>
        <div className="header-right">
          <div className="header-actions">
            <button className="action-button">
              <Search size={16} />
            </button>
            <button className="action-button">
              <Filter size={16} />
            </button>
            <button className="action-button">
              <Bell size={16} />
            </button>
            <button className="action-button">
              <Settings size={16} />
            </button>
            <button className="action-button">
              <Download size={16} />
            </button>
            <button className="action-button">
              <Share2 size={16} />
            </button>
            <button 
              className={`action-button ${showSystemPanel ? 'active' : ''}`}
              onClick={() => setShowSystemPanel(!showSystemPanel)}
            >
              <Activity size={16} />
            </button>
          </div>
          <div className="user-menu">
            <div className="user-avatar">AJ</div>
            <span>Alex Johnson</span>
            <ChevronDown size={12} className="chevron-icon" />
          </div>
        </div>
      </header>

      {/* System Status Panel */}
      {showSystemPanel && (
        <div className="system-status-panel">
          <div className="system-status-header">
            <h3>System Status</h3>
            <span className="last-updated">Last updated: 2 minutes ago</span>
          </div>
          <div className="system-status-grid">
            <div className="system-status-item">
              <div className="system-status-icon online">
                <Server size={16} />
              </div>
              <div className="system-status-info">
                <div className="system-name">Web Server</div>
                <div className="system-metrics">
                  <span className="uptime">99.9% uptime</span>
                  <span className="response-time">45ms avg</span>
                </div>
              </div>
              <div className="status-indicator online" />
            </div>
            <div className="system-status-item">
              <div className="system-status-icon online">
                <Database size={16} />
              </div>
              <div className="system-status-info">
                <div className="system-name">Database</div>
                <div className="system-metrics">
                  <span className="uptime">99.8% uptime</span>
                  <span className="response-time">12ms avg</span>
                </div>
              </div>
              <div className="status-indicator online" />
            </div>
            <div className="system-status-item">
              <div className="system-status-icon warning">
                <Globe size={16} />
              </div>
              <div className="system-status-info">
                <div className="system-name">API Gateway</div>
                <div className="system-metrics">
                  <span className="uptime">98.5% uptime</span>
                  <span className="response-time">120ms avg</span>
                </div>
              </div>
              <div className="status-indicator warning" />
            </div>
            <div className="system-status-item">
              <div className="system-status-icon online">
                <HardDrive size={16} />
              </div>
              <div className="system-status-info">
                <div className="system-name">File Storage</div>
                <div className="system-metrics">
                  <span className="uptime">99.7% uptime</span>
                  <span className="response-time">78ms avg</span>
                </div>
              </div>
              <div className="status-indicator online" />
            </div>
          </div>
        </div>
      )}

      {/* Left Panel */}
      <aside className="left-panel">
        <div className="panel-header">
          <div className="panel-tabs">
            <button 
              className={`tab-button ${activeTab === 'documents' ? 'active' : ''}`}
              onClick={() => setActiveTab('documents')}
            >
              Files
            </button>
            <button 
              className={`tab-button ${activeTab === 'tasks' ? 'active' : ''}`}
              onClick={() => setActiveTab('tasks')}
            >
              Tasks
            </button>
            <button 
              className={`tab-button ${activeTab === 'system' ? 'active' : ''}`}
              onClick={() => setActiveTab('system')}
            >
              System
            </button>
          </div>
          <p className="panel-subtitle">
            {activeTab === 'documents' ? '8 files' : 
             activeTab === 'tasks' ? '4 tasks' : 
             '4 systems'}
          </p>
        </div>
        
        <div className="search-container">
          <div className="search-input-wrapper">
            <Search size={16} className="search-icon" />
            <input
              type="text"
              placeholder={`Search ${activeTab}...`}
              className="search-input"
            />
          </div>
        </div>

        {activeTab === 'documents' && (
          <div className="categories-section">
            <div className="categories-header">
              <h3>Categories</h3>
              <button className="view-toggle" onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}>
                {viewMode === 'grid' ? <List size={16} /> : <Grid3X3 size={16} />}
              </button>
            </div>
            <div className="categories-list">
              <div className="category-item active">
                <div className="category-icon" style={{ color: '#3b82f6' }}>
                  <Folder size={16} />
                </div>
                <div className="category-info">
                  <div className="category-details">
                    <span className="category-name">All Files</span>
                    <span className="category-description">All project files</span>
                  </div>
                  <span className="category-count">8</span>
                </div>
              </div>
              <div className="category-item">
                <div className="category-icon" style={{ color: '#ef4444' }}>
                  <FileText size={16} />
                </div>
                <div className="category-info">
                  <div className="category-details">
                    <span className="category-name">Documents</span>
                    <span className="category-description">Reports and documentation</span>
                  </div>
                  <span className="category-count">2</span>
                </div>
              </div>
              <div className="category-item">
                <div className="category-icon" style={{ color: '#10b981' }}>
                  <FileText size={16} />
                </div>
                <div className="category-info">
                  <div className="category-details">
                    <span className="category-name">Code</span>
                    <span className="category-description">Source code files</span>
                  </div>
                  <span className="category-count">2</span>
                </div>
              </div>
              <div className="category-item">
                <div className="category-icon" style={{ color: '#f59e0b' }}>
                  <Database size={16} />
                </div>
                <div className="category-info">
                  <div className="category-details">
                    <span className="category-name">Data</span>
                    <span className="category-description">Data files and exports</span>
                  </div>
                  <span className="category-count">2</span>
                </div>
              </div>
              <div className="category-item">
                <div className="category-icon" style={{ color: '#8b5cf6' }}>
                  <Settings size={16} />
                </div>
                <div className="category-info">
                  <div className="category-details">
                    <span className="category-name">Config</span>
                    <span className="category-description">Configuration files</span>
                  </div>
                  <span className="category-count">1</span>
                </div>
              </div>
              <div className="category-item">
                <div className="category-icon" style={{ color: '#6b7280' }}>
                  <Archive size={16} />
                </div>
                <div className="category-info">
                  <div className="category-details">
                    <span className="category-name">Archives</span>
                    <span className="category-description">Backup and archive files</span>
                  </div>
                  <span className="category-count">1</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'documents' && (
          <div className={`documents-container ${viewMode}`}>
            <div className="documents-toolbar">
              <div className="toolbar-left">
                <button className="select-mode-button">
                  <CheckCircle size={16} />
                  Select
                </button>
              </div>
              <div className="toolbar-right">
                <div className="sort-controls">
                  <select className="sort-select">
                    <option value="name">Name</option>
                    <option value="date">Date</option>
                    <option value="size">Size</option>
                    <option value="type">Type</option>
                    <option value="priority">Priority</option>
                  </select>
                  <button className="sort-order-button">
                    <SortAsc size={16} />
                  </button>
                </div>
                <button className="filter-toggle">
                  <FilterIcon size={16} />
                </button>
              </div>
            </div>

            {viewMode === 'grid' ? (
              <div className="documents-grid">
                <div className="document-card active">
                  <div className="document-card-header">
                    <div className="document-icon" style={{ color: '#ef4444' }}>
                      <FileText size={20} />
                    </div>
                    <div className="document-actions">
                      <button className="star-button starred">
                        <Star size={14} />
                      </button>
                      <button className="more-button">
                        <MoreVertical size={14} />
                      </button>
                    </div>
                  </div>
                  <div className="document-card-content">
                    <div className="document-name">SR-LM-0006.pdf</div>
                    <div className="document-description">Technical specification document for the new interface</div>
                    <div className="document-meta">
                      <span className="document-size">7.2 MB</span>
                      <span className="document-date">10 minutes ago</span>
                    </div>
                    <div className="document-tags">
                      <span className="tag">specs</span>
                      <span className="tag">technical</span>
                    </div>
                    <div className="document-status">
                      <AlertCircle size={16} className="status-icon active" />
                      <span className="status-text">active</span>
                    </div>
                  </div>
                </div>
                <div className="document-card">
                  <div className="document-card-header">
                    <div className="document-icon" style={{ color: '#8b5cf6' }}>
                      <Settings size={20} />
                    </div>
                    <div className="document-actions">
                      <button className="star-button">
                        <Star size={14} />
                      </button>
                      <button className="more-button">
                        <MoreVertical size={14} />
                      </button>
                    </div>
                  </div>
                  <div className="document-card-content">
                    <div className="document-name">API_Configuration.json</div>
                    <div className="document-description">API configuration settings for production environment</div>
                    <div className="document-meta">
                      <span className="document-size">2.1 MB</span>
                      <span className="document-date">1 hour ago</span>
                    </div>
                    <div className="document-tags">
                      <span className="tag">api</span>
                      <span className="tag">config</span>
                    </div>
                    <div className="document-status">
                      <Clock size={16} className="status-icon pending" />
                      <span className="status-text">pending</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="documents-list">
                <div className="document-item active">
                  <div className="document-icon" style={{ color: '#ef4444' }}>
                    <FileText size={20} />
                  </div>
                  <div className="document-info">
                    <div className="document-name">SR-LM-0006.pdf</div>
                    <div className="document-description">Technical specification document for the new interface</div>
                    <div className="document-meta">
                      <span className="document-type">PDF</span>
                      <span className="document-size">7.2 MB</span>
                      <span className="document-date">10 minutes ago</span>
                    </div>
                    <div className="document-tags">
                      <span className="tag">specs</span>
                      <span className="tag">technical</span>
                      <span className="tag">interface</span>
                    </div>
                    <div className="document-details">
                      <span className="assignee">Assigned to Alex Johnson</span>
                      <span className="due-date">Due: 2024-01-30</span>
                      <div className="priority-indicator" style={{ backgroundColor: '#ef4444' }} />
                    </div>
                  </div>
                  <div className="document-actions">
                    <button className="star-button starred">
                      <Star size={14} />
                    </button>
                    <button className="document-action">
                      <Eye size={14} />
                    </button>
                    <button className="document-action">
                      <MoreVertical size={14} />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'tasks' && (
          <div className="tasks-list">
            <div className="task-item">
              <div className="task-header">
                <div className="task-title">Implement Security Features</div>
                <div className="priority-indicator" style={{ backgroundColor: '#ef4444' }} />
              </div>
              <div className="task-description">Add authentication and authorization to the new interface</div>
              <div className="task-meta">
                <span className="assignee">Assigned to Alex Johnson</span>
                <span className="due-date">Due: 2024-01-30</span>
                <span className="estimated-hours">Est: 16h</span>
                <span className="actual-hours">Actual: 12h</span>
              </div>
              <div className="task-progress">
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: '75%' }} />
                </div>
                <span className="progress-text">75%</span>
              </div>
              <div className="task-status">
                <AlertCircle size={16} className="status-icon active" />
                <span className="status-text">in-progress</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'system' && (
          <div className="system-overview">
            <div className="system-stats">
              <div className="stat-card">
                <div className="stat-icon">
                  <Activity size={20} />
                </div>
                <div className="stat-content">
                  <div className="stat-value">99.7%</div>
                  <div className="stat-label">System Uptime</div>
                </div>
              </div>
              <div className="stat-card">
                <div className="stat-icon">
                  <Zap size={20} />
                </div>
                <div className="stat-content">
                  <div className="stat-value">64ms</div>
                  <div className="stat-label">Avg Response</div>
                </div>
              </div>
              <div className="stat-card">
                <div className="stat-icon">
                  <Users size={20} />
                </div>
                <div className="stat-content">
                  <div className="stat-value">1,247</div>
                  <div className="stat-label">Active Users</div>
                </div>
              </div>
            </div>
            <div className="system-status-list">
              <div className="system-status-row">
                <div className="system-status-icon online">
                  <Server size={16} />
                </div>
                <div className="system-status-details">
                  <div className="system-name">Web Server</div>
                  <div className="system-metrics">
                    <span className="uptime">99.9% uptime</span>
                    <span className="response-time">45ms avg</span>
                  </div>
                </div>
                <div className="status-indicator online" />
              </div>
            </div>
          </div>
        )}
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        <div className="document-viewer">
          <div className="document-placeholder">
            <FileText size={64} className="document-icon-large" />
            <h3>SR-LM-0006.pdf</h3>
            <p>Document viewer will be displayed here</p>
            <div className="document-stats">
              <div className="stat">
                <span className="stat-label">Pages</span>
                <span className="stat-value">72</span>
              </div>
              <div className="stat">
                <span className="stat-label">Size</span>
                <span className="stat-value">7.2 MB</span>
              </div>
              <div className="stat">
                <span className="stat-label">Last Modified</span>
                <span className="stat-value">10 minutes ago</span>
              </div>
              <div className="stat">
                <span className="stat-label">Due Date</span>
                <span className="stat-value">Jan 30, 2024</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Right Panel - Comments & Participants */}
      <aside className="right-panel">
        <div className="panel-tabs">
          <button className="tab-button active">Comments</button>
          <button className="tab-button">Participants</button>
        </div>
        
        <div className="comments-section">
          <div className="comments-header">
            <h2 className="comments-title">Comments</h2>
            <p className="comments-count">4 comments</p>
          </div>
          <div className="comments-list">
            <div className="comment-item fade-in">
              <div className="comment-avatar">AJ</div>
              <div className="comment-content-wrapper">
                <div className="comment-header">
                  <span className="comment-author">Alex Johnson</span>
                  <span className="comment-time">1 hour ago</span>
                </div>
                <div className="comment-content">The new system architecture looks excellent! The modular approach will make maintenance much easier.</div>
                <div className="comment-actions">
                  <span className="comment-action">Reply</span>
                  <span className="comment-action">Resolve</span>
                </div>
              </div>
            </div>
            <div className="comment-item fade-in resolved">
              <div className="comment-avatar">MR</div>
              <div className="comment-content-wrapper">
                <div className="comment-header">
                  <span className="comment-author">Mike Rodriguez</span>
                  <span className="comment-time">30 minutes ago</span>
                  <span className="resolved-badge">
                    <CheckCircle size={12} />
                    Resolved
                  </span>
                </div>
                <div className="comment-content">From a technical perspective, the implementation is solid. The TypeScript integration is working perfectly.</div>
                <div className="comment-actions">
                  <span className="comment-action">Reply</span>
                  <span className="comment-action">Reopen</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="add-comment">
          <textarea
            className="comment-input"
            placeholder="Add a comment..."
          />
          <button className="comment-submit">
            Post Comment
          </button>
        </div>
      </aside>
    </div>
  );
};

export default SR_LM_0006; 