import React from 'react';
import { MoreVertical } from 'lucide-react';
import './ParticipantCard.css';

interface ParticipantCardProps {
  name: string;
  role: string;
  avatar: string;
  status: string;
  action: string;
}

const ParticipantCard: React.FC<ParticipantCardProps> = ({
  name,
  role,
  avatar,
  status,
  action
}) => {
  return (
    <div className="participant-card">
      <div className="participant-content">
        <div className="participant-info">
          <div className="checkbox-avatar">
            <input type="checkbox" className="participant-checkbox" />
            <div className="avatar-stack">
              <img src={avatar} alt={name} className="participant-avatar" />
              <div className={`status-indicator ${status}`}></div>
            </div>
          </div>
          
          <div className="participant-details">
            <div className="participant-name-role">
              <span className="participant-name">{name}</span>
              <span className="participant-role">{role}</span>
            </div>
            <div className="participant-actions">
              <MoreVertical size={16} />
            </div>
          </div>
        </div>
        
        <div className="participant-action">
          <span className="action-text">{action}</span>
        </div>
      </div>
    </div>
  );
};

export default ParticipantCard; 