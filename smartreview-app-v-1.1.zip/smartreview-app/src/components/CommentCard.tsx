import React from 'react';
import { MoreVertical } from 'lucide-react';
import './CommentCard.css';

interface CommentCardProps {
  user: string;
  avatar: string;
  timestamp: string;
  comment: string;
  rfiCount: number;
  status: string;
  isSelected?: boolean;
  onClick?: () => void;
}

const CommentCard: React.FC<CommentCardProps> = ({
  user,
  avatar,
  timestamp,
  comment,
  rfiCount,
  status,
  isSelected = false,
  onClick
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in-progress':
        return '#FFFABE';
      case 'completed':
        return '#42D98B';
      case 'pending':
        return '#FFC852';
      default:
        return '#FFFABE';
    }
  };

  const getStatusTextColor = (status: string) => {
    switch (status) {
      case 'in-progress':
        return '#A69931';
      case 'completed':
        return '#1F7A3A';
      case 'pending':
        return '#B45309';
      default:
        return '#A69931';
    }
  };

  return (
    <div 
      className={`comment-card ${isSelected ? 'selected' : ''}`}
      onClick={onClick}
    >
      <div className="comment-indicator bg-blue"></div>
      <div className="comment-content">
        <div className="comment-header">
          <div className="session-indicator">
            <div className="session-dot"></div>
            <div className="more-dots">⋮</div>
          </div>
        </div>
        
        <div className="comment-body">
          <div className="user-info">
            <img src={avatar} alt={user} className="user-avatar" />
            <div className="user-details">
              <div className="user-name-time">
                <span className="user-name">{user}</span>
                <span className="timestamp">{timestamp}</span>
              </div>
              <div className="comment-text">
                <p>{comment}</p>
                <div className="comment-actions">
                  <MoreVertical size={16} />
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="comment-footer">
          <div className="rfi-info">
            <div className="rfi-icon">📋</div>
            <span className="rfi-count">{rfiCount} RFI</span>
          </div>
          <div 
            className="status-badge"
            style={{
              backgroundColor: getStatusColor(status),
              color: getStatusTextColor(status)
            }}
          >
            <span>{status.replace('-', ' ')}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommentCard; 