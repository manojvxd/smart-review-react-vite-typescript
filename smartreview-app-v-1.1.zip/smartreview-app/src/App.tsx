import React from 'react';
import SR_DM_0005 from './components/SR-DM-0005';
import './App.css';

const App: React.FC = () => {
  return <SR_DM_0005 />;
};

export default App; 