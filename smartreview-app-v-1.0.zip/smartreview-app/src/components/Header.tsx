import React, { useState } from 'react';
import { ChevronDown, Settings, HelpCircle, Search, Bell } from 'lucide-react';
import './Header.css';

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

const Header: React.FC<HeaderProps> = ({ searchQuery, onSearchChange }) => {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [activeNavItem, setActiveNavItem] = useState('Dashboard');

  const navItems = [
    { id: 'Dashboard', label: 'Dashboard', hasDropdown: false },
    { id: 'Sessions', label: 'Sessions', hasDropdown: true },
    { id: 'Settings', label: 'Settings', hasDropdown: false, icon: Settings },
    { id: 'Help', label: 'Help', hasDropdown: false, icon: HelpCircle }
  ];

  const notifications = [
    { id: 1, message: 'New comment on IRD_Doc_08_06_2025.pdf', time: '2 min ago' },
    { id: 2, message: 'Document review completed', time: '1 hour ago' },
    { id: 3, message: 'New participant joined the session', time: '3 hours ago' }
  ];

  return (
    <header className="header">
      <div className="header-content">
        <div className="header-left">
          <div className="logo-section">
            <img src="/images/logo.svg" alt="SmartReview Logo" className="logo" />
          </div>
          
          <nav className="navigation">
            {navItems.map((item) => {
              const IconComponent = item.icon;
              return (
                <div 
                  key={item.id}
                  className={`nav-item ${activeNavItem === item.id ? 'active' : ''}`}
                  onClick={() => setActiveNavItem(item.id)}
                >
                  {IconComponent && <IconComponent size={16} />}
                  <span>{item.label}</span>
                  {item.hasDropdown && <ChevronDown size={16} />}
                </div>
              );
            })}
          </nav>
        </div>
        
        <div className="header-right">
          <div className="search-section">
            <div className="search-container">
              <Search size={16} className="search-icon" />
              <input
                type="text"
                placeholder="Search documents, comments..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="search-input"
              />
            </div>
          </div>

          <div className="header-actions">
            <div className="notification-bell" onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}>
              <Bell size={20} />
              <span className="notification-badge">3</span>
              {isNotificationsOpen && (
                <div className="notifications-dropdown">
                  <div className="notifications-header">
                    <h4>Notifications</h4>
                    <button className="mark-all-read">Mark all read</button>
                  </div>
                  <div className="notifications-list">
                    {notifications.map((notification) => (
                      <div key={notification.id} className="notification-item">
                        <div className="notification-content">
                          <p>{notification.message}</p>
                          <span className="notification-time">{notification.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            <div className="user-profile" onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}>
              <div className="user-info">
                <span className="user-name">Delight Jose</span>
                <span className="user-role">Manager</span>
              </div>
              <div className="user-avatar">
                <div className="avatar-ring"></div>
                <img src="/images/avatar-delight.svg" alt="User Avatar" className="avatar" />
                <ChevronDown size={16} className="avatar-dropdown" />
              </div>
              
              {isUserMenuOpen && (
                <div className="user-menu-dropdown">
                  <div className="menu-item">
                    <span>Profile</span>
                  </div>
                  <div className="menu-item">
                    <span>Settings</span>
                  </div>
                  <div className="menu-divider"></div>
                  <div className="menu-item">
                    <span>Sign Out</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header; 
