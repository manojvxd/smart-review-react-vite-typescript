import React, { useState, useEffect } from 'react';
import { User, MessageSquare, FileText, ChevronDown } from 'lucide-react';
import './SR-LM-0001.css';

interface Participant {
  id: string;
  name: string;
  role: string;
  avatar: string;
  isActive: boolean;
}

interface Comment {
  id: string;
  author: string;
  content: string;
  timestamp: string;
}

const SR_LM_0001: React.FC = () => {
  const [participants, setParticipants] = useState<Participant[]>([
    {
      id: '1',
      name: 'John Doe',
      role: 'Project Manager',
      avatar: 'JD',
      isActive: true
    },
    {
      id: '2',
      name: 'Jane Smith',
      role: 'Designer',
      avatar: 'JS',
      isActive: true
    },
    {
      id: '3',
      name: 'Mike Johnson',
      role: 'Developer',
      avatar: 'MJ',
      isActive: true
    },
    {
      id: '4',
      name: 'Sarah Brown',
      role: 'QA Engineer',
      avatar: 'SB',
      isActive: true
    }
  ]);

  const [comments, setComments] = useState<Comment[]>([
    {
      id: '1',
      author: 'John Doe',
      content: 'The layout looks great! I think we should consider adding more spacing between the header elements for better readability.',
      timestamp: '2 hours ago'
    },
    {
      id: '2',
      author: 'Jane Smith',
      content: 'I agree with John\'s feedback. The spacing could be improved. Also, should we consider using a different color scheme for the active states?',
      timestamp: '1 hour ago'
    },
    {
      id: '3',
      author: 'Mike Johnson',
      content: 'The technical implementation looks solid. I\'ve reviewed the code and everything seems to be working as expected.',
      timestamp: '30 minutes ago'
    }
  ]);

  const [selectedParticipant, setSelectedParticipant] = useState<string>('1');
  const [newComment, setNewComment] = useState<string>('');

  const handleParticipantSelect = (participantId: string) => {
    setSelectedParticipant(participantId);
  };

  const handleAddComment = () => {
    if (newComment.trim()) {
      const comment: Comment = {
        id: Date.now().toString(),
        author: 'You',
        content: newComment.trim(),
        timestamp: 'Just now'
      };
      setComments(prev => [comment, ...prev]);
      setNewComment('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleAddComment();
    }
  };

  return (
    <div className="app-container">
      {/* Header */}
      <header className="header">
        <div className="header-left">
          <a href="#" className="logo">SmartReview</a>
          <div className="breadcrumb">
            <span>Projects</span>
            <span className="breadcrumb-separator">/</span>
            <span>Document Review</span>
            <span className="breadcrumb-separator">/</span>
            <span>SR-LM-0001</span>
          </div>
        </div>
        <div className="header-right">
          <div className="user-menu">
            <div className="user-avatar">JD</div>
            <span>John Doe</span>
            <ChevronDown size={12} className="chevron-icon" />
          </div>
        </div>
      </header>

      {/* Left Panel - Participants */}
      <aside className="left-panel">
        <div className="panel-header">
          <h2 className="panel-title">Participants</h2>
          <p className="panel-subtitle">{participants.length} team members</p>
        </div>
        <div className="participants-list">
          {participants.map((participant) => (
            <div
              key={participant.id}
              className={`participant-item ${selectedParticipant === participant.id ? 'active' : ''}`}
              onClick={() => handleParticipantSelect(participant.id)}
            >
              <div className="participant-avatar">{participant.avatar}</div>
              <div className="participant-info">
                <div className="participant-name">{participant.name}</div>
                <div className="participant-role">{participant.role}</div>
              </div>
              <div className="participant-status"></div>
            </div>
          ))}
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        <div className="document-viewer">
          <div className="document-placeholder">
            <FileText size={48} className="document-icon" />
            <h3>SR-LM-0001.pdf</h3>
            <p>Document viewer will be displayed here</p>
          </div>
        </div>
      </main>

      {/* Right Panel - Comments */}
      <aside className="right-panel">
        <div className="comments-section">
          <div className="comments-header">
            <h2 className="comments-title">Comments</h2>
            <p className="comments-count">{comments.length} comments</p>
          </div>
          <div className="comments-list">
            {comments.map((comment) => (
              <div key={comment.id} className="comment-item fade-in">
                <div className="comment-header">
                  <span className="comment-author">{comment.author}</span>
                  <span className="comment-time">{comment.timestamp}</span>
                </div>
                <div className="comment-content">{comment.content}</div>
                <div className="comment-actions">
                  <span className="comment-action">Reply</span>
                  <span className="comment-action">Resolve</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="add-comment">
          <textarea
            className="comment-input"
            placeholder="Add a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            onKeyDown={handleKeyPress}
          />
          <button className="comment-submit" onClick={handleAddComment}>
            Post Comment
          </button>
        </div>
      </aside>
    </div>
  );
};

export default SR_LM_0001; 