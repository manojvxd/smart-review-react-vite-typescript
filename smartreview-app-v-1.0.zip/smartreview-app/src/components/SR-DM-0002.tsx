import React, { useState, useEffect } from 'react';
import { User, MessageSquare, FileText, ChevronDown, Search, Filter, MoreVertical, Download, Share2, Eye } from 'lucide-react';
import './SR-DM-0002.css';

interface Document {
  id: string;
  name: string;
  type: string;
  size: string;
  lastModified: string;
  status: 'active' | 'inactive' | 'pending';
  thumbnail?: string;
}

interface Comment {
  id: string;
  author: string;
  content: string;
  timestamp: string;
  avatar: string;
  replies?: Comment[];
}

interface Participant {
  id: string;
  name: string;
  role: string;
  avatar: string;
  isActive: boolean;
  status: 'online' | 'offline' | 'away';
}

const SR_DM_0002: React.FC = () => {
  const [documents, setDocuments] = useState<Document[]>([
    {
      id: '1',
      name: 'SR-DM-0002.pdf',
      type: 'PDF',
      size: '2.4 MB',
      lastModified: '2 hours ago',
      status: 'active'
    },
    {
      id: '2',
      name: 'Technical_Specifications.docx',
      type: 'DOCX',
      size: '1.8 MB',
      lastModified: '1 day ago',
      status: 'active'
    },
    {
      id: '3',
      name: 'Design_Mockups.fig',
      type: 'FIG',
      size: '5.2 MB',
      lastModified: '3 days ago',
      status: 'pending'
    },
    {
      id: '4',
      name: 'Project_Timeline.xlsx',
      type: 'XLSX',
      size: '890 KB',
      lastModified: '1 week ago',
      status: 'inactive'
    }
  ]);

  const [participants, setParticipants] = useState<Participant[]>([
    {
      id: '1',
      name: 'Alex Johnson',
      role: 'Project Lead',
      avatar: 'AJ',
      isActive: true,
      status: 'online'
    },
    {
      id: '2',
      name: 'Sarah Chen',
      role: 'UI/UX Designer',
      avatar: 'SC',
      isActive: true,
      status: 'online'
    },
    {
      id: '3',
      name: 'Mike Rodriguez',
      role: 'Frontend Developer',
      avatar: 'MR',
      isActive: true,
      status: 'away'
    },
    {
      id: '4',
      name: 'Emily Davis',
      role: 'QA Engineer',
      avatar: 'ED',
      isActive: false,
      status: 'offline'
    }
  ]);

  const [comments, setComments] = useState<Comment[]>([
    {
      id: '1',
      author: 'Alex Johnson',
      content: 'The new design layout looks excellent! The spacing and typography improvements really enhance the user experience.',
      timestamp: '1 hour ago',
      avatar: 'AJ'
    },
    {
      id: '2',
      author: 'Sarah Chen',
      content: 'I agree with Alex. The color scheme is much more cohesive now. Should we consider adding more interactive elements?',
      timestamp: '45 minutes ago',
      avatar: 'SC'
    },
    {
      id: '3',
      author: 'Mike Rodriguez',
      content: 'From a technical perspective, the implementation is solid. The component structure is clean and maintainable.',
      timestamp: '30 minutes ago',
      avatar: 'MR'
    }
  ]);

  const [selectedDocument, setSelectedDocument] = useState<string>('1');
  const [selectedParticipant, setSelectedParticipant] = useState<string>('1');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [newComment, setNewComment] = useState<string>('');

  const handleDocumentSelect = (documentId: string) => {
    setSelectedDocument(documentId);
  };

  const handleParticipantSelect = (participantId: string) => {
    setSelectedParticipant(participantId);
  };

  const handleAddComment = () => {
    if (newComment.trim()) {
      const comment: Comment = {
        id: Date.now().toString(),
        author: 'You',
        content: newComment.trim(),
        timestamp: 'Just now',
        avatar: 'YO'
      };
      setComments(prev => [comment, ...prev]);
      setNewComment('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleAddComment();
    }
  };

  const filteredDocuments = documents.filter(doc =>
    doc.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="app-container">
      {/* Header */}
      <header className="header">
        <div className="header-left">
          <a href="#" className="logo">SmartReview</a>
          <div className="breadcrumb">
            <span>Projects</span>
            <span className="breadcrumb-separator">/</span>
            <span>Document Review</span>
            <span className="breadcrumb-separator">/</span>
            <span>SR-DM-0002</span>
          </div>
        </div>
        <div className="header-right">
          <div className="header-actions">
            <button className="action-button">
              <Search size={16} />
            </button>
            <button className="action-button">
              <Filter size={16} />
            </button>
            <button className="action-button">
              <Download size={16} />
            </button>
            <button className="action-button">
              <Share2 size={16} />
            </button>
          </div>
          <div className="user-menu">
            <div className="user-avatar">AJ</div>
            <span>Alex Johnson</span>
            <ChevronDown size={12} className="chevron-icon" />
          </div>
        </div>
      </header>

      {/* Left Panel - Documents */}
      <aside className="left-panel">
        <div className="panel-header">
          <h2 className="panel-title">Documents</h2>
          <p className="panel-subtitle">{documents.length} files</p>
        </div>
        <div className="search-container">
          <div className="search-input-wrapper">
            <Search size={16} className="search-icon" />
            <input
              type="text"
              placeholder="Search documents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
            />
          </div>
        </div>
        <div className="documents-list">
          {filteredDocuments.map((document) => (
            <div
              key={document.id}
              className={`document-item ${selectedDocument === document.id ? 'active' : ''}`}
              onClick={() => handleDocumentSelect(document.id)}
            >
              <div className="document-icon">
                <FileText size={20} />
              </div>
              <div className="document-info">
                <div className="document-name">{document.name}</div>
                <div className="document-meta">
                  <span className="document-type">{document.type}</span>
                  <span className="document-size">{document.size}</span>
                  <span className="document-date">{document.lastModified}</span>
                </div>
              </div>
              <div className="document-actions">
                <button className="document-action">
                  <Eye size={14} />
                </button>
                <button className="document-action">
                  <MoreVertical size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        <div className="document-viewer">
          <div className="document-placeholder">
            <FileText size={64} className="document-icon-large" />
            <h3>SR-DM-0002.pdf</h3>
            <p>Document viewer will be displayed here</p>
            <div className="document-stats">
              <div className="stat">
                <span className="stat-label">Pages</span>
                <span className="stat-value">24</span>
              </div>
              <div className="stat">
                <span className="stat-label">Size</span>
                <span className="stat-value">2.4 MB</span>
              </div>
              <div className="stat">
                <span className="stat-label">Last Modified</span>
                <span className="stat-value">2 hours ago</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Right Panel - Comments & Participants */}
      <aside className="right-panel">
        <div className="panel-tabs">
          <button className="tab-button active">Comments</button>
          <button className="tab-button">Participants</button>
        </div>
        
        <div className="comments-section">
          <div className="comments-header">
            <h2 className="comments-title">Comments</h2>
            <p className="comments-count">{comments.length} comments</p>
          </div>
          <div className="comments-list">
            {comments.map((comment) => (
              <div key={comment.id} className="comment-item fade-in">
                <div className="comment-avatar">{comment.avatar}</div>
                <div className="comment-content-wrapper">
                  <div className="comment-header">
                    <span className="comment-author">{comment.author}</span>
                    <span className="comment-time">{comment.timestamp}</span>
                  </div>
                  <div className="comment-content">{comment.content}</div>
                  <div className="comment-actions">
                    <span className="comment-action">Reply</span>
                    <span className="comment-action">Resolve</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="add-comment">
          <textarea
            className="comment-input"
            placeholder="Add a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            onKeyDown={handleKeyPress}
          />
          <button className="comment-submit" onClick={handleAddComment}>
            Post Comment
          </button>
        </div>
      </aside>
    </div>
  );
};

export default SR_DM_0002; 