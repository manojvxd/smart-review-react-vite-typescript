import React, { useState } from 'react';
import { ChevronUp, ChevronDown, MessageSquare, Users, Search, MoreVertical, Plus } from 'lucide-react';
import CommentCard from './CommentCard';
import ParticipantCard from './ParticipantCard';
import './RightPanel.css';

interface Comment {
  id: number;
  user: string;
  avatar: string;
  timestamp: string;
  comment: string;
  rfiCount: number;
  status: 'in-progress' | 'completed' | 'pending';
  isSelected?: boolean;
}

interface Participant {
  id: number;
  name: string;
  role: string;
  avatar: string;
  status: 'online' | 'offline' | 'away';
  action: string;
}

interface RightPanelProps {
  comments: Comment[];
  participants: Participant[];
  selectedComment: number | null;
  onCommentSelect: (commentId: number) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const RightPanel: React.FC<RightPanelProps> = ({
  comments,
  participants,
  selectedComment,
  onCommentSelect,
  isCollapsed,
  onToggleCollapse
}) => {
  const [isCommentsExpanded, setIsCommentsExpanded] = useState(true);
  const [isParticipantsExpanded, setIsParticipantsExpanded] = useState(true);
  const [sortBy, setSortBy] = useState('date');
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredComments = comments.filter(comment => {
    const matchesSearch = comment.comment.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         comment.user.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || comment.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const sortedComments = [...filteredComments].sort((a, b) => {
    if (sortBy === 'date') {
      return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    }
    return a.user.localeCompare(b.user);
  });

  const handleCommentClick = (commentId: number) => {
    onCommentSelect(commentId);
  };

  const handleAddComment = () => {
    // Simulate adding a new comment
    console.log('Adding new comment');
  };

  return (
    <div className={`right-panel ${isCollapsed ? 'collapsed' : ''}`}>
      {/* Collapse Toggle Button */}
      <button 
        className="panel-toggle-btn"
        onClick={onToggleCollapse}
        title={isCollapsed ? 'Expand Panel' : 'Collapse Panel'}
      >
        <ChevronDown className={isCollapsed ? 'rotate' : ''} size={16} />
      </button>

      {/* Comments Section */}
      <div className="panel-section comments-section">
        <div 
          className="section-header"
          onClick={() => setIsCommentsExpanded(!isCommentsExpanded)}
        >
          <MessageSquare size={16} />
          <span>Comments ({comments.length})</span>
          <div className="header-actions">
            <button className="action-btn" onClick={handleAddComment} title="Add Comment">
              <Plus size={14} />
            </button>
            {isCommentsExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </div>
        </div>
        
        {isCommentsExpanded && (
          <>
            <div className="comments-controls">
              <div className="search-filter">
                <div className="search-container">
                  <Search size={14} className="search-icon" />
                  <input
                    type="text"
                    placeholder="Search comments..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="search-input"
                  />
                </div>
                <div className="filter-controls">
                  <select 
                    value={filterStatus} 
                    onChange={(e) => setFilterStatus(e.target.value)}
                    className="filter-select"
                  >
                    <option value="all">All Status</option>
                    <option value="in-progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="pending">Pending</option>
                  </select>
                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value)}
                    className="sort-select"
                  >
                    <option value="date">Sort by Date</option>
                    <option value="user">Sort by User</option>
                  </select>
                </div>
              </div>
            </div>
            
            <div className="comments-list">
              {sortedComments.length > 0 ? (
                sortedComments.map((comment) => (
                  <CommentCard 
                    key={comment.id} 
                    {...comment}
                    isSelected={selectedComment === comment.id}
                    onClick={() => handleCommentClick(comment.id)}
                  />
                ))
              ) : (
                <div className="no-comments">
                  <div className="no-comments-icon">💬</div>
                  <p>No comments found</p>
                  <button className="add-comment-btn" onClick={handleAddComment}>
                    Add First Comment
                  </button>
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* Participants Section */}
      <div className="panel-section participants-section">
        <div 
          className="section-header"
          onClick={() => setIsParticipantsExpanded(!isParticipantsExpanded)}
        >
          <Users size={16} />
          <span>Participants ({participants.length})</span>
          <div className="header-actions">
            <button className="action-btn" title="Search Participants">
              <Search size={14} />
            </button>
            <button className="action-btn" title="More Options">
              <MoreVertical size={14} />
            </button>
            {isParticipantsExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </div>
        </div>
        
        {isParticipantsExpanded && (
          <div className="participants-list">
            {participants.map((participant) => (
              <ParticipantCard key={participant.id} {...participant} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default RightPanel; 