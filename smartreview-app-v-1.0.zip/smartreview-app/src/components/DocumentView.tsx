import React, { useState } from 'react';
import { ArrowLeft, ZoomIn, ZoomOut, Download, Share2, MoreVertical, Eye, RotateCw } from 'lucide-react';
import './DocumentView.css';

interface Document {
  id: string;
  name: string;
  info: string;
  docNumber: string;
  sheetNumber: string;
  status: 'active' | 'inactive';
  type: 'pdf' | 'doc' | 'xls';
}

interface DocumentViewProps {
  selectedDocument?: Document;
}

const DocumentView: React.FC<DocumentViewProps> = ({ selectedDocument }) => {
  const [zoomLevel, setZoomLevel] = useState(100);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [rotation, setRotation] = useState(0);

  const handleZoomIn = () => {
    setZoomLevel(prev => Math.min(prev + 25, 200));
  };

  const handleZoomOut = () => {
    setZoomLevel(prev => Math.max(prev - 25, 50));
  };

  const handleRotate = () => {
    setRotation(prev => (prev + 90) % 360);
  };

  const handleDownload = () => {
    // Simulate download
    console.log('Downloading document:', selectedDocument?.name);
  };

  const handleShare = () => {
    // Simulate share functionality
    console.log('Sharing document:', selectedDocument?.name);
  };

  const handleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  if (!selectedDocument) {
    return (
      <div className="document-view">
        <div className="document-placeholder">
          <div className="placeholder-content">
            <div className="placeholder-icon">📄</div>
            <h3>No Document Selected</h3>
            <p>Select a document from the left panel to view it here</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`document-view ${isFullscreen ? 'fullscreen' : ''}`}>
      <div className="document-header">
        <div className="document-title">
          <button className="back-button">
            <ArrowLeft size={16} />
            <span>Go Back</span>
          </button>
          <div className="document-info">
            <h2>{selectedDocument.name}</h2>
            <div className="document-meta">
              <span className="doc-number">Doc: #{selectedDocument.docNumber}</span>
              <span className="sheet-number">Sheet: {selectedDocument.sheetNumber}</span>
              <span className={`status-badge ${selectedDocument.status}`}>
                {selectedDocument.status}
              </span>
            </div>
          </div>
        </div>
        
        <div className="document-controls">
          <div className="zoom-controls">
            <button 
              className="control-btn" 
              onClick={handleZoomOut}
              disabled={zoomLevel <= 50}
              title="Zoom Out"
            >
              <ZoomOut size={16} />
            </button>
            <span className="zoom-level">{zoomLevel}%</span>
            <button 
              className="control-btn" 
              onClick={handleZoomIn}
              disabled={zoomLevel >= 200}
              title="Zoom In"
            >
              <ZoomIn size={16} />
            </button>
          </div>
          
          <div className="action-controls">
            <button className="control-btn" onClick={handleRotate} title="Rotate">
              <RotateCw size={16} />
            </button>
            <button className="control-btn" onClick={handleDownload} title="Download">
              <Download size={16} />
            </button>
            <button className="control-btn" onClick={handleShare} title="Share">
              <Share2 size={16} />
            </button>
            <button className="control-btn" onClick={handleFullscreen} title="Fullscreen">
              <Eye size={16} />
            </button>
            <button className="control-btn" title="More Options">
              <MoreVertical size={16} />
            </button>
          </div>
        </div>
      </div>
      
      <div className="document-content">
        <div className="document-preview">
          <div 
            className="preview-container"
            style={{ 
              transform: `scale(${zoomLevel / 100}) rotate(${rotation}deg)`,
              transformOrigin: 'center center'
            }}
          >
            <img 
              src="/images/document-preview.png" 
              alt="Document Preview" 
              className="preview-image"
            />
            
            {/* Document annotations overlay */}
            <div className="annotations-overlay">
              <div className="annotation comment-annotation" style={{ top: '20%', left: '30%' }}>
                <div className="annotation-marker"></div>
                <div className="annotation-content">
                  <span className="annotation-text">Change title to 'Pipeline System'</span>
                </div>
              </div>
              
              <div className="annotation highlight-annotation" style={{ top: '45%', left: '60%' }}>
                <div className="annotation-marker"></div>
                <div className="annotation-content">
                  <span className="annotation-text">Review this section</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Document navigation */}
        <div className="document-navigation">
          <div className="page-info">
            <span>Page 1 of 15</span>
          </div>
          <div className="page-controls">
            <button className="page-btn" disabled>Previous</button>
            <div className="page-numbers">
              <button className="page-number active">1</button>
              <button className="page-number">2</button>
              <button className="page-number">3</button>
              <span className="page-ellipsis">...</span>
              <button className="page-number">15</button>
            </div>
            <button className="page-btn">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentView; 